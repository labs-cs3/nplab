#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
  
    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);

    // if (num1 < 0 || num2 < 0 || num1 > 255 || num2 > 255) {
    //     fprintf(stderr, "Please enter two small non-negative numbers (0-255).\n");
    //     return EXIT_FAILURE;
    // }

    pid_t pid = fork();

     if (pid == 0) { 
        int sum = num1 + num2;
        printf("Child process: Sum of %d and %d is %d\n", num1, num2, sum);
        exit(sum); 
    } else {
        int status;
        waitpid(pid, &status, 0); 
        int sum = WEXITSTATUS(status);
        printf("Parent process: Received sum %d from child process\n", sum);
    }

    return EXIT_SUCCESS;
}
