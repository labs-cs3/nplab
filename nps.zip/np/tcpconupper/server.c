#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <fcntl.h>
#include<ctype.c>

#define PORT 12345
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 10



void handle_client(int client_socket) {

    char buffer[BUFFER_SIZE];
    int n;

    n = read(client_socket, buffer, BUFFER_SIZE);
   
    for (int i = 0; i < n; ++i)
        buffer[i] = toupper(buffer[i]);

    n = write(client_socket, buffer, n);

    close(client_socket);
}

int main() {
    int server_socket, client_socket, max_sd, sd, activity, i;
    int client_socket_list[MAX_CLIENTS];
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    fd_set readfds;

    for (i = 0; i < MAX_CLIENTS; i++)
        client_socket_list[i] = 0;

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
   

    int opt = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    memset((char *) &server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    bind(server_socket, (struct sockaddr *) &server_addr, sizeof(server_addr));

    listen(server_socket, 5);
    printf("Server listening on port %d...\n", PORT);

    while (1) {
        FD_ZERO(&readfds);
        FD_SET(server_socket, &readfds);
        max_sd = server_socket;

        for (i = 0; i < MAX_CLIENTS; i++) {
            sd = client_socket_list[i];
            if (sd > 0)
                FD_SET(sd, &readfds);
            if (sd > max_sd)
                max_sd = sd;
        }

        activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
      

        if (FD_ISSET(server_socket, &readfds)) {
            client_socket = accept(server_socket, (struct sockaddr *) &client_addr, &addr_len);
           
            for (i = 0; i < MAX_CLIENTS; i++) {
                if (client_socket_list[i] == 0) {
                    client_socket_list[i] = client_socket;
                    break;
                }
            }
        }

        for (i = 0; i < MAX_CLIENTS; i++) {
            sd = client_socket_list[i];
            if (FD_ISSET(sd, &readfds)) {
                handle_client(sd);
                client_socket_list[i] = 0;
            }
        }
    }

    close(server_socket);
    return 0;
}
