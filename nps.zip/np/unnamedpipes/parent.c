#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define BUFFER_SIZE 256


int main() {
    int pipefd[2];
    pid_t pid;
    char buffer[BUFFER_SIZE];

    pipe(pipefd);

    pid = fork();
   

    if (pid == 0) { 
        close(pipefd[1]); 
        read(pipefd[0], buffer, BUFFER_SIZE);
        printf("Child received: %s\n", buffer);
        close(pipefd[0]); 
    } else { 
        close(pipefd[0]); 
        const char *message = "Hello from parent!";
        if (write(pipefd[1], message, strlen(message) + 1));
        close(pipefd[1]); 
        wait(NULL);
    }

    return 0;
}
