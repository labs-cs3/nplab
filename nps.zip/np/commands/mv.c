#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>



int main(int argc, char *argv[]) {
   

    const char *source = argv[1];
    const char *destination = argv[2];

    if (rename(source, destination) != 0) {
        perror("mv");
        exit(EXIT_FAILURE);
    }

    printf("Moved %s to %s\n", source, destination);
    return 0;
}
