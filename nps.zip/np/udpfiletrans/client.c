#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
 
#define SERV_PORT 30000
#define MAXLINE 4096
 

 
int main(int argc, char **argv) {
    int sockfd;
    struct sockaddr_in servaddr;
    char buf[MAXLINE];
    ssize_t n;
 
    if (argc != 3) {
        exit(1);
    }
 
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
 
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(SERV_PORT);
    if (inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0) err_sys("inet_pton error");
 
    FILE *fp = fopen(argv[2], "rb");
 
    printf("Client is sending file: %s to server: %s\n", argv[2], argv[1]);
 
    while ((n = fread(buf, sizeof(char), MAXLINE, fp)) > 0) {

        printf("Read %zd bytes from file\n", n);

        sendto(sockfd, buf, n, 0, (struct sockaddr *) &servaddr, sizeof(servaddr))

        printf("Sent %zd bytes to server\n", n);
    }
 
    fclose(fp);
    close(sockfd);
 
    return 0;
}


