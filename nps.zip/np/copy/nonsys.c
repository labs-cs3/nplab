#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  
    FILE *src = fopen(argv[1], "rb");
 
    FILE *dest = fopen(argv[2], "wb");
   
    char buffer[BUFSIZ];
    size_t n;

    while ((n = fread(buffer, 1, sizeof(buffer), src)) > 0) {
        fwrite(buffer, 1, n, dest);
    }

    fclose(src);
    fclose(dest);

    return 0;
}
