#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define QUEUE_KEY 12345
#define BUFFER_SIZE 1024
struct message {
    long msg_type;
    char msg_text[BUFFER_SIZE];
};
int main() {
    int msgid;
    struct message msg;
    msgid = msgget(QUEUE_KEY, 0666 | IPC_CREAT);
    printf("Waiting for messages...\n");
    while (1) {
        if (msgrcv(msgid, &msg, sizeof(msg.msg_text), 0, 0));
         printf("Received message: %s\n", msg.msg_text);
    }
    msgctl(msgid, IPC_RMID, NULL);
    return 0;
}
