#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#define QUEUE_KEY 12345
#define BUFFER_SIZE 1024
struct message {
    long msg_type;
    char msg_text[BUFFER_SIZE];
};
int main() {
    int msgid;
    struct message msg;
    msgid = msgget(QUEUE_KEY, 0666 | IPC_CREAT);
    msg.msg_type = 1;
    while (1) {
        printf("Enter message: ");
        fgets(msg.msg_text, BUFFER_SIZE, stdin);
        msg.msg_text[strcspn(msg.msg_text, "\n")] = '\0';
        msgsnd(msgid, &msg, sizeof(msg.msg_text), 0); 
    }
    return 0;
}
