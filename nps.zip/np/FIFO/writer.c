#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define FIFO_NAME "/tmp/my_fifo"
#define BUFFER_SIZE 256


int main() {
    int fd;
    char buffer[BUFFER_SIZE];

    mkfifo(FIFO_NAME, 0666);
    fd = open(FIFO_NAME, O_WRONLY);

    printf("Enter messages to send. Type 'exit' to quit.\n");

    while (1) {

        printf("Enter message: ");
        fgets(buffer, BUFFER_SIZE, stdin);

        buffer[strcspn(buffer, "\n")] = '\0';

        if (strcmp(buffer, "exit") == 0) {
            break;
        }

        write(fd, buffer, strlen(buffer));
    }

    close(fd);

    return 0;
}
