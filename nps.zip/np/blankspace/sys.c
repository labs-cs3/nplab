#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

int main(int argc, char *argv[]) {
  

    int file = open(argv[1], O_RDONLY);
 

    char buffer[BUFSIZ];
    ssize_t n;
    int space_count = 0;

    while ((n = read(file, buffer, sizeof(buffer))) > 0) {
        for (ssize_t i = 0; i < n; i++) {
            if (buffer[i] == ' ') {
                space_count++;
            }
        }
    }

    close(file);

    printf("Number of blank spaces: %d\n", space_count);

    return EXIT_SUCCESS;
}
