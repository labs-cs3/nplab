#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    

    FILE *file = fopen(argv[1], "r");
  

    int ch;
    int space_count = 0;

    while ((ch = fgetc(file)) != EOF) {
        if (ch == ' ') {
            space_count++;
        }
    }

    fclose(file);

    printf("Number of blank spaces: %d\n", space_count);

    return EXIT_SUCCESS;
}
